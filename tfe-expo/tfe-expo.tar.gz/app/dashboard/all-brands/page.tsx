"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

const NAV_SECTIONS = [
  {
    label: "EVENT",
    items: [
      { name: "Dashboard", badge: null, path: "/dashboard" },
      { name: "My matched brands", badge: 3, path: "/dashboard/matched-brands" },
      { name: "My schedule", badge: 4, path: "/dashboard/schedule" },
      { name: "Speed connect", badge: 2, path: "/dashboard/speed-connect" },
    ],
  },
  {
    label: "DISCOVER",
    items: [
      { name: "Education sessions", badge: null, path: "/dashboard/education" },
      { name: "All brands", badge: null, path: "/dashboard/all-brands" },
    ],
  },
  {
    label: "MY ACTIVITY",
    items: [
      { name: "Saved brands", badge: null, path: "/dashboard/saved-brands" },
      { name: "Notes & history", badge: null, path: "/dashboard/notes" },
    ],
  },
];

const BRAND_COLORS: Record<string, string> = {
  "fine-ink-studios": "bg-slate-900",
  "jag-cantina": "bg-amber-800",
  "complete-outdoor-living": "bg-emerald-800",
};

function getBrandColor(slug: string): string {
  if (BRAND_COLORS[slug]) return BRAND_COLORS[slug];
  const colors = [
    "bg-blue-800", "bg-purple-800", "bg-teal-800",
    "bg-rose-800", "bg-orange-800", "bg-indigo-800",
  ];
  const index = slug.split("").reduce((acc, c) => acc + c.charCodeAt(0), 0) % colors.length;
  return colors[index];
}

function getInitials(name: string): string {
  return name.split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase();
}

function formatInvestment(min: number, max: number): string {
  const fmt = (v: number) => v >= 1000000 ? `$${(v / 1000000).toFixed(1)}M` : `$${Math.round(v / 1000)}K`;
  return `${fmt(min)}–${fmt(max)}`;
}

type Brand = {
  id: string;
  name: string;
  slug: string;
  category: string;
  ownership_model: string;
  investment_min: number;
  investment_max: number;
  available_states: string[];
  item19_present: boolean;
  sba_eligible: boolean;
  unit_count: number;
};

const CATEGORIES = ["All categories", "Health & beauty", "Food & beverage", "Home services", "Fitness & wellness", "B2B services", "Pet services", "Education & tutoring", "Retail"];
const INVESTMENT_RANGES = ["Any investment", "Under $100K", "$100K–$200K", "$200K–$400K", "$400K+"];
const MODELS = ["Any model", "Semi-absentee", "Owner-operator", "Multi-unit"];

const MATCH_SCORES: Record<string, number> = {
  "fine-ink-studios": 97,
  "jag-cantina": 88,
  "complete-outdoor-living": 82,
};

export default function AllBrandsPage() {
  const router = useRouter();
  const [activeNav, setActiveNav] = useState("All brands");
  const [brands, setBrands] = useState<Brand[]>([]);
  const [loading, setLoading] = useState(true);
  const [category, setCategory] = useState("All categories");
  const [investment, setInvestment] = useState("Any investment");
  const [model, setModel] = useState("Any model");
  const [item19Only, setItem19Only] = useState(false);

  useEffect(() => {
    async function fetchBrands() {
      try {
        const res = await fetch("/api/brands");
        const data = await res.json() as { brands: Brand[] };
        setBrands(data.brands ?? []);
      } catch (err) {
        console.error("Failed to fetch brands:", err);
      } finally {
        setLoading(false);
      }
    }
    fetchBrands();
  }, []);

  const filtered = brands.filter((b) => {
    if (category !== "All categories" && b.category !== category) return false;
    if (model !== "Any model" && b.ownership_model !== model.toLowerCase()) return false;
    if (item19Only && !b.item19_present) return false;
    if (investment !== "Any investment") {
      const min = b.investment_min;
      if (investment === "Under $100K" && min >= 100000) return false;
      if (investment === "$100K–$200K" && (min < 100000 || min >= 200000)) return false;
      if (investment === "$200K–$400K" && (min < 200000 || min >= 400000)) return false;
      if (investment === "$400K+" && min < 400000) return false;
    }
    return true;
  });

  return (
    <div className="flex min-h-screen bg-white text-slate-900">
      {/* Sidebar */}
      <aside className="flex w-56 shrink-0 flex-col bg-slate-900 text-white">
        <div className="px-5 pt-6 pb-4">
          <p className="text-sm font-semibold">
            <span className="text-amber-400">The Franchise Edge</span>
          </p>
          <p className="text-xs text-slate-400">Virtual Expo · Spring 2026 · Live now</p>
        </div>

        <div className="mx-4 mb-6 flex items-center gap-3 rounded-lg bg-slate-800 px-3 py-3">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-amber-500 text-xs font-bold text-white">SC</div>
          <div>
            <p className="text-sm font-medium">Scott C.</p>
            <p className="text-xs text-slate-400">Readiness score: 82 · 3 matches</p>
          </div>
        </div>

        <nav className="flex-1 space-y-5 px-4">
          {NAV_SECTIONS.map((section) => (
            <div key={section.label}>
              <p className="mb-2 text-xs font-semibold tracking-widest text-slate-500">{section.label}</p>
              <ul className="space-y-1">
                {section.items.map((item) => (
                  <li key={item.name}>
                    <button
                      onClick={() => { setActiveNav(item.name); router.push(item.path); }}
                      className={`flex w-full items-center justify-between rounded-lg px-3 py-2 text-sm transition ${activeNav === item.name ? "bg-slate-700 text-white" : "text-slate-400 hover:bg-slate-800 hover:text-white"}`}
                    >
                      <span className="flex items-center gap-2">
                        <span className="h-1.5 w-1.5 rounded-full bg-slate-500" />
                        {item.name}
                      </span>
                      {item.badge && (
                        <span className="rounded-full bg-amber-500 px-1.5 py-0.5 text-xs font-semibold text-white">{item.badge}</span>
                      )}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </nav>

        <div className="px-5 py-5">
          <p className="text-xs text-slate-500">Pressure guarantee:</p>
          <p className="text-xs text-amber-400">promise@thefranchiseedge.com</p>
        </div>
      </aside>

      {/* Main */}
      <div className="flex flex-1 flex-col">
        <div className="flex items-center justify-between border-b border-slate-100 px-8 py-4">
          <h1 className="text-lg font-semibold">All brands</h1>
          <div className="flex items-center gap-6 text-sm text-slate-500">
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-emerald-500" />
              Event is live
            </span>
            <span>Day 1 · 1:42 PM ET</span>
          </div>
        </div>

        <main className="flex-1 px-8 py-8">
          {/* Filters */}
          <div className="mb-6 flex flex-wrap items-center gap-3">
            <select value={category} onChange={(e) => setCategory(e.target.value)} className="rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-slate-300">
              {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
            </select>
            <select value={investment} onChange={(e) => setInvestment(e.target.value)} className="rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-slate-300">
              {INVESTMENT_RANGES.map((r) => <option key={r}>{r}</option>)}
            </select>
            <select value={model} onChange={(e) => setModel(e.target.value)} className="rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-slate-300">
              {MODELS.map((m) => <option key={m}>{m}</option>)}
            </select>
            <label className="flex cursor-pointer items-center gap-2 text-sm text-slate-600">
              <input type="checkbox" checked={item19Only} onChange={(e) => setItem19Only(e.target.checked)} className="rounded" />
              Item 19 only
            </label>
            <p className="ml-auto text-sm text-slate-400">
              {loading ? "Loading..." : `${filtered.length} of ${brands.length} brands`}
            </p>
          </div>

          {loading ? (
            <p className="text-sm text-slate-400">Loading brands...</p>
          ) : (
            <div className="divide-y divide-slate-100">
              {filtered.map((brand) => (
                <button
                  key={brand.id}
                  onClick={() => router.push(`/dashboard/pavilion/${brand.slug}`)}
                  className="flex w-full items-center gap-5 py-4 text-left transition hover:bg-slate-50"
                >
                  <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-lg ${getBrandColor(brand.slug)} text-xs font-bold text-white`}>
                    {getInitials(brand.name)}
                  </div>
                  <div className="w-44 shrink-0">
                    <p className="text-sm font-medium">{brand.name}</p>
                    <p className="text-xs text-slate-500">{brand.category}</p>
                  </div>
                  <div className="w-32 shrink-0">
                    <p className="text-xs text-slate-500 capitalize">{brand.ownership_model}</p>
                  </div>
                  <div className="w-32 shrink-0">
                    <p className="text-sm">{formatInvestment(brand.investment_min, brand.investment_max)}</p>
                  </div>
                  <div className="w-20 shrink-0">
                    <p className="text-xs text-slate-500">
                      {brand.available_states?.length ? brand.available_states.slice(0, 2).join(", ") : "National"}
                    </p>
                  </div>
                  <div className="w-20 shrink-0">
                    {brand.item19_present ? (
                      <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-xs font-medium text-emerald-700">Item 19</span>
                    ) : (
                      <span className="text-xs text-slate-300">—</span>
                    )}
                  </div>
                  <div className="ml-auto text-right">
                    {MATCH_SCORES[brand.slug] ? (
                      <p className="text-sm font-semibold text-emerald-600">{MATCH_SCORES[brand.slug]}% match</p>
                    ) : (
                      <p className="text-xs text-slate-300">—</p>
                    )}
                  </div>
                </button>
              ))}
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
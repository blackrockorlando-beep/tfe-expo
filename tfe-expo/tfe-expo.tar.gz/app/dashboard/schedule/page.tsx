"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

const NAV_SECTIONS = [
  {
    label: "EVENT",
    items: [
      { name: "Dashboard", badge: null, path: "/dashboard" },
      { name: "My matched brands", badge: 3, path: "/dashboard/matched-brands" },
      { name: "My schedule", badge: 4, path: "/dashboard/schedule" },
      { name: "Speed connect", badge: 2, path: "/dashboard/speed-connect" },
    ],
  },
  {
    label: "DISCOVER",
    items: [
      { name: "Education sessions", badge: null, path: "/dashboard/education" },
      { name: "All brands", badge: null, path: "/dashboard/all-brands" },
    ],
  },
  {
    label: "MY ACTIVITY",
    items: [
      { name: "Saved brands", badge: null, path: "/dashboard/saved-brands" },
      { name: "Notes & history", badge: null, path: "/dashboard/notes" },
    ],
  },
];

const SCHEDULE_ITEMS = [
  {
    time: "9:00 AM",
    title: "TFE education: How to read a franchise FDD",
    detail: "45 min · TFE hosted · Completed",
    status: "Attended",
    statusStyle: "text-slate-400",
  },
  {
    time: "10:00 AM",
    title: "TFE education: What Item 19 actually means",
    detail: "45 min · TFE hosted · Completed",
    status: "Attended",
    statusStyle: "text-slate-400",
  },
  {
    time: "11:00 AM",
    title: "Brand pitch: Complete Outdoor Living · Stage 2",
    detail: "30 min · Paul Samson presenting",
    status: "Upcoming",
    statusStyle: "text-slate-400",
  },
  {
    time: "12:30 PM",
    title: "Lunch break — pavilion open",
    detail: "Browse matched brands at your own pace",
    status: "Upcoming",
    statusStyle: "text-slate-400",
  },
  {
    time: "2:30 PM",
    title: "Brand pitch: Fine Ink Studios · Stage 3",
    detail: "30 min · Myranda T. presenting · Starting soon",
    status: "Live now",
    statusStyle: "text-emerald-600 font-semibold",
  },
  {
    time: "3:30 PM",
    title: "Speed connect: Fine Ink Studios",
    detail: "10 min · Myranda T. · 1-on-1 video",
    status: "Upcoming",
    statusStyle: "text-slate-400",
  },
  {
    time: "4:00 PM",
    title: "Speed connect: Complete Outdoor Living",
    detail: "10 min · Paul Samson · 1-on-1 video",
    status: "Upcoming",
    statusStyle: "text-slate-400",
  },
  {
    time: "5:00 PM",
    title: "TFE education: SBA financing for franchise buyers",
    detail: "45 min · TFE hosted · Recording available",
    status: "Upcoming",
    statusStyle: "text-slate-400",
  },
];

export default function SchedulePage() {
  const router = useRouter();
  const [activeNav, setActiveNav] = useState("My schedule");

  return (
    <div className="flex min-h-screen bg-white text-slate-900">
      {/* Sidebar */}
      <aside className="flex w-56 shrink-0 flex-col bg-slate-900 text-white">
        <div className="px-5 pt-6 pb-4">
          <p className="text-sm font-semibold">
            <span className="text-amber-400">The Franchise Edge</span>
          </p>
          <p className="text-xs text-slate-400">
            Virtual Expo · Spring 2026 · Live now
          </p>
        </div>

        <div className="mx-4 mb-6 flex items-center gap-3 rounded-lg bg-slate-800 px-3 py-3">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-amber-500 text-xs font-bold text-white">
            SC
          </div>
          <div>
            <p className="text-sm font-medium">Scott C.</p>
            <p className="text-xs text-slate-400">
              Readiness score: 82 · 3 matches
            </p>
          </div>
        </div>

        <nav className="flex-1 space-y-5 px-4">
          {NAV_SECTIONS.map((section) => (
            <div key={section.label}>
              <p className="mb-2 text-xs font-semibold tracking-widest text-slate-500">
                {section.label}
              </p>
              <ul className="space-y-1">
                {section.items.map((item) => (
                  <li key={item.name}>
                    <button
                      onClick={() => {
                        setActiveNav(item.name);
                        router.push(item.path);
                      }}
                      className={`flex w-full items-center justify-between rounded-lg px-3 py-2 text-sm transition ${
                        activeNav === item.name
                          ? "bg-slate-700 text-white"
                          : "text-slate-400 hover:bg-slate-800 hover:text-white"
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        <span className="h-1.5 w-1.5 rounded-full bg-slate-500" />
                        {item.name}
                      </span>
                      {item.badge && (
                        <span className="rounded-full bg-amber-500 px-1.5 py-0.5 text-xs font-semibold text-white">
                          {item.badge}
                        </span>
                      )}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </nav>

        <div className="px-5 py-5">
          <p className="text-xs text-slate-500">Pressure guarantee:</p>
          <p className="text-xs text-amber-400">promise@thefranchiseedge.com</p>
        </div>
      </aside>

      {/* Main */}
      <div className="flex flex-1 flex-col">
        <div className="flex items-center justify-between border-b border-slate-100 px-8 py-4">
          <h1 className="text-lg font-semibold">My schedule</h1>
          <div className="flex items-center gap-6 text-sm text-slate-500">
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-emerald-500" />
              Event is live
            </span>
            <span>Day 1 · 1:42 PM ET</span>
          </div>
        </div>

        <main className="flex-1 px-8 py-8">
          <div className="divide-y divide-slate-100">
            {SCHEDULE_ITEMS.map((item, i) => (
              <div key={i} className="flex items-start gap-8 py-5">
                <div className="w-20 shrink-0">
                  <p className="text-sm font-medium text-slate-700">
                    {item.time}
                  </p>
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium">{item.title}</p>
                  <p className="mt-0.5 text-xs text-slate-500">{item.detail}</p>
                </div>
                <div className="w-20 shrink-0 text-right">
                  <p className={`text-sm ${item.statusStyle}`}>{item.status}</p>
                </div>
              </div>
            ))}
          </div>
        </main>
      </div>
    </div>
  );
}
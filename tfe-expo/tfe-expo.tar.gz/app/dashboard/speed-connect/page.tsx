"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

const NAV_SECTIONS = [
  {
    label: "EVENT",
    items: [
      { name: "Dashboard", badge: null, path: "/dashboard" },
      { name: "My matched brands", badge: 3, path: "/dashboard/matched-brands" },
      { name: "My schedule", badge: 4, path: "/dashboard/schedule" },
      { name: "Speed connect", badge: 2, path: "/dashboard/speed-connect" },
    ],
  },
  {
    label: "DISCOVER",
    items: [
      { name: "Education sessions", badge: null, path: "/dashboard/education" },
      { name: "All brands", badge: null, path: "/dashboard/all-brands" },
    ],
  },
  {
    label: "MY ACTIVITY",
    items: [
      { name: "Saved brands", badge: null, path: "/dashboard/saved-brands" },
      { name: "Notes & history", badge: null, path: "/dashboard/notes" },
    ],
  },
];

const SESSIONS = [
  {
    time: "3:30 PM",
    initials: "FI",
    color: "bg-slate-900",
    brand: "Fine Ink Studios",
    contact: "Myranda T. · Director of Booking",
    status: "Confirmed",
    statusStyle: "text-slate-500",
    action: null,
  },
  {
    time: "4:00 PM",
    initials: "CO",
    color: "bg-emerald-800",
    brand: "Complete Outdoor Living",
    contact: "Paul Samson · Co-Founder, TFE",
    status: "Confirmed",
    statusStyle: "text-slate-500",
    action: null,
  },
  {
    time: "—",
    initials: "JC",
    color: "bg-amber-800",
    brand: "Jag Cantina",
    contact: "Scott Anderson · Co-Founder, TFE",
    status: "Book now",
    statusStyle: "text-amber-600 font-semibold",
    action: "Book now",
  },
];

export default function SpeedConnectPage() {
  const router = useRouter();
  const [activeNav, setActiveNav] = useState("Speed connect");

  return (
    <div className="flex min-h-screen bg-white text-slate-900">
      {/* Sidebar */}
      <aside className="flex w-56 shrink-0 flex-col bg-slate-900 text-white">
        <div className="px-5 pt-6 pb-4">
          <p className="text-sm font-semibold">
            <span className="text-amber-400">The Franchise Edge</span>
          </p>
          <p className="text-xs text-slate-400">
            Virtual Expo · Spring 2026 · Live now
          </p>
        </div>

        <div className="mx-4 mb-6 flex items-center gap-3 rounded-lg bg-slate-800 px-3 py-3">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-amber-500 text-xs font-bold text-white">
            SC
          </div>
          <div>
            <p className="text-sm font-medium">Scott C.</p>
            <p className="text-xs text-slate-400">
              Readiness score: 82 · 3 matches
            </p>
          </div>
        </div>

        <nav className="flex-1 space-y-5 px-4">
          {NAV_SECTIONS.map((section) => (
            <div key={section.label}>
              <p className="mb-2 text-xs font-semibold tracking-widest text-slate-500">
                {section.label}
              </p>
              <ul className="space-y-1">
                {section.items.map((item) => (
                  <li key={item.name}>
                    <button
                      onClick={() => {
                        setActiveNav(item.name);
                        router.push(item.path);
                      }}
                      className={`flex w-full items-center justify-between rounded-lg px-3 py-2 text-sm transition ${
                        activeNav === item.name
                          ? "bg-slate-700 text-white"
                          : "text-slate-400 hover:bg-slate-800 hover:text-white"
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        <span className="h-1.5 w-1.5 rounded-full bg-slate-500" />
                        {item.name}
                      </span>
                      {item.badge && (
                        <span className="rounded-full bg-amber-500 px-1.5 py-0.5 text-xs font-semibold text-white">
                          {item.badge}
                        </span>
                      )}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </nav>

        <div className="px-5 py-5">
          <p className="text-xs text-slate-500">Pressure guarantee:</p>
          <p className="text-xs text-amber-400">promise@thefranchiseedge.com</p>
        </div>
      </aside>

      {/* Main */}
      <div className="flex flex-1 flex-col">
        <div className="flex items-center justify-between border-b border-slate-100 px-8 py-4">
          <h1 className="text-lg font-semibold">Speed connect meetings</h1>
          <div className="flex items-center gap-6 text-sm text-slate-500">
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-emerald-500" />
              Event is live
            </span>
            <span>Day 1 · 1:42 PM ET</span>
          </div>
        </div>

        <main className="flex-1 px-8 py-8">
          <p className="mb-8 text-sm text-slate-500">
            Your speed connect sessions are 10-minute, AI-matched 1-on-1 video
            meetings. Notes auto-save. No brand can follow up more than twice
            without your invitation.
          </p>

          {/* Sessions */}
          <div className="divide-y divide-slate-100">
            {SESSIONS.map((session, i) => (
              <div key={i} className="flex items-center gap-6 py-5">
                <div className="w-16 shrink-0">
                  <p className="text-sm font-medium text-slate-600">
                    {session.time}
                  </p>
                </div>
                <div
                  className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-lg ${session.color} text-xs font-bold text-white`}
                >
                  {session.initials}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium">{session.brand}</p>
                  <p className="text-xs text-slate-500">{session.contact}</p>
                </div>
                <div className="text-right">
                  <p className={`text-sm ${session.statusStyle}`}>
                    {session.status}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Prep tips */}
          <div className="mt-10 border-t border-slate-100 pt-8">
            <p className="mb-2 text-sm font-semibold">
              Preparing for your sessions
            </p>
            <p className="text-sm text-slate-500">
              Review each brand's pavilion and Item 19 before your session.
              Prepare 1–2 specific questions. Have your territory preference and
              timeline ready to confirm. Use the shared notes panel during the
              call — both parties see it in real time.
            </p>
          </div>
        </main>
      </div>
    </div>
  );
}
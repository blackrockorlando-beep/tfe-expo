"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

const BRANDS = [
  {
    initials: "FI",
    color: "bg-slate-900",
    name: "Fine Ink Studios",
    description: "Tattoo & piercing · $127K–$185K · FL",
    match: 97,
    status: "Pavilion viewed · Pitch next at 2:30pm",
    dot: true,
  },
  {
    initials: "CO",
    color: "bg-emerald-800",
    name: "Complete Outdoor Living",
    description: "Outdoor kitchen · $145K–$220K · SE US",
    match: 82,
    status: "Speed connect at 4:00pm today",
    dot: true,
  },
  {
    initials: "JC",
    color: "bg-amber-800",
    name: "Jag Cantina",
    description: "Modern Mexican · $280K–$420K · FL",
    match: 88,
    status: "Not yet visited — pitch at 4:00pm",
    dot: false,
  },
];

const SCHEDULE = [
  {
    time: "2:30 PM",
    type: "BRAND PITCH STAGE",
    typeColor: "text-slate-700",
    title: "Fine Ink Studios · Stage 3",
    detail: "30 min · live Q&A included",
    action: "Join session",
  },
  {
    time: "3:30 PM",
    type: "SPEED CONNECT",
    typeColor: "text-amber-600",
    title: "Fine Ink Studios · Myranda T.",
    detail: "10 min · 1-on-1 video",
    action: "Prepare notes",
  },
  {
    time: "4:00 PM",
    type: "SPEED CONNECT",
    typeColor: "text-amber-600",
    title: "Complete Outdoor Living · Paul S.",
    detail: "10 min · 1-on-1 video",
    action: "Prepare notes",
  },
  {
    time: "5:00 PM",
    type: "EDUCATION SESSION",
    typeColor: "text-slate-700",
    title: "SBA financing for franchise buyers",
    detail: "45 min · TFE hosted · recording available",
    action: null,
  },
];

const NAV_SECTIONS = [
  {
    label: "EVENT",
    items: [
      { name: "Dashboard", badge: null, path: "/dashboard" },
      { name: "My matched brands", badge: 3, path: "/dashboard/matched-brands" },
      { name: "My schedule", badge: 4, path: "/dashboard/schedule" },
      { name: "Speed connect", badge: 2, path: "/dashboard/speed-connect" },
    ],
  },
  {
    label: "DISCOVER",
    items: [
      { name: "Education sessions", badge: null, path: "/dashboard/education" },
      { name: "All brands", badge: null, path: "/dashboard/all-brands" },
    ],
  },
  {
    label: "MY ACTIVITY",
    items: [
      { name: "Saved brands", badge: null, path: "/dashboard/saved-brands" },
      { name: "Notes & history", badge: null, path: "/dashboard/notes" },
    ],
  },
];

export default function DashboardPage() {
  const router = useRouter();
  const [activeNav, setActiveNav] = useState("Dashboard");

  return (
    <div className="flex min-h-screen bg-white text-slate-900">
      <aside className="flex w-56 shrink-0 flex-col bg-slate-900 text-white">
        <div className="px-5 pt-6 pb-4">
          <p className="text-sm font-semibold">
            <span className="text-amber-400">The Franchise Edge</span>
          </p>
          <p className="text-xs text-slate-400">
            Virtual Expo · Spring 2026 · Live now
          </p>
        </div>

        <div className="mx-4 mb-6 flex items-center gap-3 rounded-lg bg-slate-800 px-3 py-3">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-amber-500 text-xs font-bold text-white">
            SC
          </div>
          <div>
            <p className="text-sm font-medium">Scott C.</p>
            <p className="text-xs text-slate-400">
              Readiness score: 82 · 3 matches
            </p>
          </div>
        </div>

        <nav className="flex-1 space-y-5 px-4">
          {NAV_SECTIONS.map((section) => (
            <div key={section.label}>
              <p className="mb-2 text-xs font-semibold tracking-widest text-slate-500">
                {section.label}
              </p>
              <ul className="space-y-1">
                {section.items.map((item) => (
                  <li key={item.name}>
                    <button
                      onClick={() => {
                        setActiveNav(item.name);
                        router.push(item.path);
                      }}
                      className={`flex w-full items-center justify-between rounded-lg px-3 py-2 text-sm transition ${
                        activeNav === item.name
                          ? "bg-slate-700 text-white"
                          : "text-slate-400 hover:bg-slate-800 hover:text-white"
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        <span className="h-1.5 w-1.5 rounded-full bg-slate-500" />
                        {item.name}
                      </span>
                      {item.badge && (
                        <span className="rounded-full bg-amber-500 px-1.5 py-0.5 text-xs font-semibold text-white">
                          {item.badge}
                        </span>
                      )}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </nav>

        <div className="px-5 py-5">
          <p className="text-xs text-slate-500">Pressure guarantee:</p>
          <p className="text-xs text-amber-400">promise@thefranchiseedge.com</p>
        </div>
      </aside>

      <div className="flex flex-1 flex-col">
        <div className="flex items-center justify-between border-b border-slate-100 px-8 py-4">
          <h1 className="text-lg font-semibold">Your dashboard</h1>
          <div className="flex items-center gap-6 text-sm text-slate-500">
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-emerald-500" />
              Event is live
            </span>
            <span>Day 1 · 1:42 PM ET</span>
          </div>
        </div>

        <main className="flex-1 overflow-y-auto px-8 py-8">
          <div className="grid grid-cols-4 gap-8 border-b border-slate-100 pb-8">
            <div>
              <p className="text-3xl font-semibold">82</p>
              <p className="mt-1 text-sm text-slate-600">Readiness score</p>
              <p className="text-xs text-slate-400">Top 22% of attendees</p>
            </div>
            <div>
              <p className="text-3xl font-semibold">3</p>
              <p className="mt-1 text-sm text-slate-600">Matched brands</p>
              <p className="text-xs text-slate-400">Based on your profile</p>
            </div>
            <div>
              <p className="text-3xl font-semibold text-amber-500">2</p>
              <p className="mt-1 text-sm text-slate-600">Sessions attended</p>
              <p className="text-xs text-slate-400">2 remaining today</p>
            </div>
            <div>
              <p className="text-3xl font-semibold">2</p>
              <p className="mt-1 text-sm text-slate-600">Speed connects</p>
              <p className="text-xs text-slate-400">Confirmed · today</p>
            </div>
          </div>

          <div className="mt-8">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-base font-semibold">Up next today</h2>
              <button
                onClick={() => router.push("/dashboard/schedule")}
                className="text-sm text-slate-500 hover:text-slate-900"
              >
                Full schedule →
              </button>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              {SCHEDULE.map((item, i) => (
                <div
                  key={i}
                  className="flex gap-5 rounded-xl border border-slate-100 bg-slate-50 px-5 py-4"
                >
                  <div className="w-14 shrink-0">
                    <p className="text-sm font-semibold">{item.time}</p>
                  </div>
                  <div className="flex-1">
                    <p className={`text-xs font-semibold tracking-wide ${item.typeColor}`}>
                      {item.type}
                    </p>
                    <p className="mt-0.5 text-sm font-medium">{item.title}</p>
                    <p className="text-xs text-slate-500">{item.detail}</p>
                    {item.action && (
                      <button className="mt-3 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-medium transition hover:bg-slate-100">
                        {item.action}
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-10">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-base font-semibold">Your matched brands</h2>
              <button
                onClick={() => router.push("/dashboard/matched-brands")}
                className="text-sm text-slate-500 hover:text-slate-900"
              >
                View all →
              </button>
            </div>
            <div className="space-y-3">
              {BRANDS.map((brand) => (
                <div
                  key={brand.name}
                  className="flex cursor-pointer items-center gap-4 rounded-xl border border-slate-100 bg-white px-5 py-4 shadow-sm transition hover:border-slate-300"
                >
                  <div className="relative">
                    <div
                      className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-lg ${brand.color} text-xs font-bold text-white`}
                    >
                      {brand.initials}
                    </div>
                    {brand.dot && (
                      <span className="absolute -bottom-1 left-1/2 h-1.5 w-1.5 -translate-x-1/2 rounded-full bg-amber-500" />
                    )}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">{brand.name}</p>
                    <p className="text-xs text-slate-500">{brand.description}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-semibold text-emerald-600">
                      {brand.match}% match
                    </p>
                    <p className="text-xs text-slate-400">{brand.status}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
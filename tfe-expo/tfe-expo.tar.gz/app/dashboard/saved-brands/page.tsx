"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

const NAV_SECTIONS = [
  {
    label: "EVENT",
    items: [
      { name: "Dashboard", badge: null, path: "/dashboard" },
      { name: "My matched brands", badge: 3, path: "/dashboard/matched-brands" },
      { name: "My schedule", badge: 4, path: "/dashboard/schedule" },
      { name: "Speed connect", badge: 2, path: "/dashboard/speed-connect" },
    ],
  },
  {
    label: "DISCOVER",
    items: [
      { name: "Education sessions", badge: null, path: "/dashboard/education" },
      { name: "All brands", badge: null, path: "/dashboard/all-brands" },
    ],
  },
  {
    label: "MY ACTIVITY",
    items: [
      { name: "Saved brands", badge: null, path: "/dashboard/saved-brands" },
      { name: "Notes & history", badge: null, path: "/dashboard/notes" },
    ],
  },
];

const SAVED = [
  {
    initials: "FI",
    color: "bg-slate-900",
    name: "Fine Ink Studios",
    description: "Tattoo & piercing · semi-absentee",
    investment: "$127K–185K",
    metric: "$552K AUV",
    match: 97,
    status: "Saved · Pitch 2:30pm today",
    path: "/dashboard/pavilion/fine-ink-studios",
  },
  {
    initials: "CO",
    color: "bg-emerald-800",
    name: "Complete Outdoor Living",
    description: "Outdoor kitchen design · semi-absentee",
    investment: "$145K–$220K",
    metric: "$95K avg. GP",
    match: 82,
    status: "Saved · Speed connect 4pm",
    path: "/dashboard/pavilion/complete-outdoor-living",
  },
];

export default function SavedBrandsPage() {
  const router = useRouter();
  const [activeNav, setActiveNav] = useState("Saved brands");

  return (
    <div className="flex min-h-screen bg-white text-slate-900">
      {/* Sidebar */}
      <aside className="flex w-56 shrink-0 flex-col bg-slate-900 text-white">
        <div className="px-5 pt-6 pb-4">
          <p className="text-sm font-semibold">
            <span className="text-amber-400">The Franchise Edge</span>
          </p>
          <p className="text-xs text-slate-400">
            Virtual Expo · Spring 2026 · Live now
          </p>
        </div>

        <div className="mx-4 mb-6 flex items-center gap-3 rounded-lg bg-slate-800 px-3 py-3">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-amber-500 text-xs font-bold text-white">
            SC
          </div>
          <div>
            <p className="text-sm font-medium">Scott C.</p>
            <p className="text-xs text-slate-400">
              Readiness score: 82 · 3 matches
            </p>
          </div>
        </div>

        <nav className="flex-1 space-y-5 px-4">
          {NAV_SECTIONS.map((section) => (
            <div key={section.label}>
              <p className="mb-2 text-xs font-semibold tracking-widest text-slate-500">
                {section.label}
              </p>
              <ul className="space-y-1">
                {section.items.map((item) => (
                  <li key={item.name}>
                    <button
                      onClick={() => {
                        setActiveNav(item.name);
                        router.push(item.path);
                      }}
                      className={`flex w-full items-center justify-between rounded-lg px-3 py-2 text-sm transition ${
                        activeNav === item.name
                          ? "bg-slate-700 text-white"
                          : "text-slate-400 hover:bg-slate-800 hover:text-white"
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        <span className="h-1.5 w-1.5 rounded-full bg-slate-500" />
                        {item.name}
                      </span>
                      {item.badge && (
                        <span className="rounded-full bg-amber-500 px-1.5 py-0.5 text-xs font-semibold text-white">
                          {item.badge}
                        </span>
                      )}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </nav>

        <div className="px-5 py-5">
          <p className="text-xs text-slate-500">Pressure guarantee:</p>
          <p className="text-xs text-amber-400">promise@thefranchiseedge.com</p>
        </div>
      </aside>

      {/* Main */}
      <div className="flex flex-1 flex-col">
        <div className="flex items-center justify-between border-b border-slate-100 px-8 py-4">
          <h1 className="text-lg font-semibold">Saved brands</h1>
          <div className="flex items-center gap-6 text-sm text-slate-500">
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-emerald-500" />
              Event is live
            </span>
            <span>Day 1 · 1:42 PM ET</span>
          </div>
        </div>

        <main className="flex-1 px-8 py-8">
          <p className="mb-6 text-sm text-slate-500">
            Brands you've saved for later review. Saving a brand does not
            notify the franchisor.
          </p>

          <div className="divide-y divide-slate-100">
            {SAVED.map((brand) => (
              <button
                key={brand.name}
                onClick={() => router.push(brand.path)}
                className="flex w-full items-center gap-5 py-5 text-left transition hover:bg-slate-50"
              >
                <div
                  className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-lg ${brand.color} text-xs font-bold text-white`}
                >
                  {brand.initials}
                </div>
                <div className="w-52 shrink-0">
                  <p className="text-sm font-medium">{brand.name}</p>
                  <p className="text-xs text-slate-500">{brand.description}</p>
                </div>
                <div className="w-32 shrink-0">
                  <p className="text-sm">{brand.investment}</p>
                </div>
                <div className="w-32 shrink-0">
                  <p className="text-sm text-slate-600">{brand.metric}</p>
                </div>
                <div className="ml-auto text-right">
                  <p className="text-sm font-semibold text-emerald-600">
                    {brand.match}%
                  </p>
                  <p className="mt-0.5 text-xs text-slate-400">
                    {brand.status}
                  </p>
                </div>
              </button>
            ))}
          </div>
        </main>
      </div>
    </div>
  );
}
"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";

const NAV_SECTIONS = [
  {
    label: "EVENT",
    items: [
      { name: "Dashboard", badge: null, path: "/dashboard" },
      { name: "My matched brands", badge: 3, path: "/dashboard/matched-brands" },
      { name: "My schedule", badge: 4, path: "/dashboard/schedule" },
      { name: "Speed connect", badge: 2, path: "/dashboard/speed-connect" },
    ],
  },
  {
    label: "DISCOVER",
    items: [
      { name: "Education sessions", badge: null, path: "/dashboard/education" },
      { name: "All brands", badge: null, path: "/dashboard/all-brands" },
    ],
  },
  {
    label: "MY ACTIVITY",
    items: [
      { name: "Saved brands", badge: null, path: "/dashboard/saved-brands" },
      { name: "Notes & history", badge: null, path: "/dashboard/notes" },
    ],
  },
];

const TABS = [
  "Overview",
  "Item 19 — earnings",
  "Franchisee validation",
  "Territory",
  "Support model",
  "Documents",
];

const BRAND_COLORS: Record<string, string> = {
  "fine-ink-studios": "bg-slate-900",
  "jag-cantina": "bg-amber-800",
  "complete-outdoor-living": "bg-emerald-800",
};

type Brand = {
  id: string;
  name: string;
  slug: string;
  category: string;
  description: string;
  investment_min: number;
  investment_max: number;
  auv: number;
  royalty_pct: number;
  franchise_fee: number;
  item19_present: boolean;
  sba_eligible: boolean;
  available_states: string[];
  ownership_model: string;
  unit_count: number;
  rep_name: string;
  rep_title: string;
  payback_period: string;
  tags: string[];
  overview: string;
  ownership_model_detail: string;
  artist_structure: string;
  location_type: string;
  operating_hours: string;
  staff_at_open: string;
  revenue_mix: string;
  years_franchising: string;
  rep_availability: string;
  pitch_time: string;
  pitch_stage: string;
  pitch_duration: string;
  item19_summary: string;
  item19_avg_gross_revenue: number;
  item19_top_quartile_gross: number;
  item19_median_gross: number;
  item19_bottom_quartile_gross: number;
  item19_locations_reporting: number;
  item19_fiscal_year: string;
  item19_notes: string;
  item19_cogs_amount: number;
  item19_cogs_pct: number;
  item19_artist_commissions_amount: number;
  item19_artist_commissions_pct: number;
  item19_rent_amount: number;
  item19_rent_pct: number;
  item19_royalty_amount: number;
  item19_royalty_
  item19_owner_earnings_pct: number;
  validation_intro: string;
  territory_description: string;
  franchisee_validations: {
    id: string;
    initials: string;
    name: string;
    location: string;
    months_open: number;
    quote: string;
    rating: number;
    display_order: number;
  }[];
  territories: {
    id: string;
    territory_name: string;
    status: string;
    display_order: number;
  
    id: string;
    initials: string;
    name: string;
    location: string;
    months_open: number;
    quote: string;
    rating: number;
    display_order: number;
  }[];
  territories: {
    id: string;
    territory_name: string;
    status: string;
    display_order: number;
  }[];
  support_onthejob_hours: number;
  support_classroom_hours: number;
  support_values: {
    provided: boolean;
    support_items: {
      id: string;
      item_name: string;
      support_type: string;
      display_order: number;
    };
  }[];
  documents: {
    id: string;
    title: string;
    description: string;
    access_type: string;
    file_url: string | null;
    display_order: number;
  }[];
};

function formatCurrency(value: number): string {
  if (value >= 1000000) return `$${(value / 1000000).toFixed(1)}M`;
  if (value >= 1000) return `$${Math.round(value / 1000)}K`;
  return `$${value}`;
}

function getInitials(name: string): string {
  return name
    .split(" ")
    .map((w) => w[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();
}

export default function PavilionPage() {
  const router = useRouter();
  const params = useParams();
  const slug = params.slug as string;

  const [brand, setBrand] = useState<Brand | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState("Overview");
  const [activeNav, setActiveNav] = useState("My matched brands");

  useEffect(() => {
    async function fetchBrand() {
      try {
        const res = await fetch(`/api/brands/${slug}`);
        const data = await res.json() as { brand?: Brand; error?: string };
        if (!res.ok) throw new Error(data.error ?? "Failed to load brand.");
        setBrand(data.brand ?? null);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to load brand.");
      } finally {
        setLoading(false);
      }
    }
    fetchBrand();
  }, [slug]);

  const color = BRAND_COLORS[slug] ?? "bg-slate-700";

  const matchBadges = [
    brand?.item19_present ? "Item 19 included" : null,
    brand?.sba_eligible ? "SBA eligible" : null,
    brand?.available_states?.length
      ? `${brand.available_states[0]} territories open`
      : null,
    brand?.unit_count ? `${brand.unit_count}+ open locations` : null,
  ].filter(Boolean) as string[];

  return (
    <div className="flex min-h-screen bg-white text-slate-900">
      {/* Sidebar */}
      <aside className="flex w-56 shrink-0 flex-col bg-slate-900 text-white">
        <div className="px-5 pt-6 pb-4">
          <p className="text-sm font-semibold">
            <span className="text-amber-400">The Franchise Edge</span>
          </p>
          <p className="text-xs text-slate-400">
            Virtual Expo · Spring 2026 · Live now
          </p>
        </div>

        <div className="mx-4 mb-6 flex items-center gap-3 rounded-lg bg-slate-800 px-3 py-3">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-amber-500 text-xs font-bold text-white">
            SC
          </div>
          <div>
            <p className="text-sm font-medium">Scott C.</p>
            <p className="text-xs text-slate-400">Readiness score: 82 · 3 matches</p>
          </div>
        </div>

        <nav className="flex-1 space-y-5 px-4">
          {NAV_SECTIONS.map((section) => (
            <div key={section.label}>
              <p className="mb-2 text-xs font-semibold tracking-widest text-slate-500">
                {section.label}
              </p>
              <ul className="space-y-1">
                {section.items.map((item) => (
                  <li key={item.name}>
                    <button
                      onClick={() => {
                        setActiveNav(item.name);
                        router.push(item.path);
                      }}
                      className={`flex w-full items-center justify-between rounded-lg px-3 py-2 text-sm transition ${
                        activeNav === item.name
                          ? "bg-slate-700 text-white"
                          : "text-slate-400 hover:bg-slate-800 hover:text-white"
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        <span className="h-1.5 w-1.5 rounded-full bg-slate-500" />
                        {item.name}
                      </span>
                      {item.badge && (
                        <span className="rounded-full bg-amber-500 px-1.5 py-0.5 text-xs font-semibold text-white">
                          {item.badge}
                        </span>
                      )}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </nav>

        <div className="px-5 py-5">
          <p className="text-xs text-slate-500">Pressure guarantee:</p>
          <p className="text-xs text-amber-400">promise@thefranchiseedge.com</p>
        </div>
      </aside>

      {/* Main */}
      <div className="flex flex-1 flex-col">
        {loading && (
          <div className="flex flex-1 items-center justify-center">
            <p className="text-sm text-slate-400">Loading...</p>
          </div>
        )}

        {error && (
          <div className="flex flex-1 items-center justify-center">
            <p className="text-sm text-red-500">{error}</p>
          </div>
        )}

        {brand && (
          <>
            {/* Breadcrumb */}
            <div className="border-b border-slate-100 px-8 py-3 text-xs text-slate-400">
              <button
                onClick={() => router.push("/dashboard/matched-brands")}
                className="hover:text-slate-700"
              >
                Pavilion
              </button>
              {" › "}
              <span>{brand.category}</span>
              {" › "}
              <span className="text-slate-700">{brand.name}</span>
            </div>

            {/* Brand header */}
            <div className="flex items-center justify-between bg-slate-900 px-8 py-5">
              <div className="flex items-center gap-4">
                <div
                  className={`flex h-12 w-12 items-center justify-center rounded-lg ${color} text-sm font-bold text-white`}
                >
                  {getInitials(brand.name)}
                </div>
                <div>
                  <p className="text-lg font-semibold text-white">{brand.name}</p>
                  <p className="text-sm text-amber-400">
                    {brand.tags?.join(" · ") ?? brand.category}
                  </p>
                </div>
              </div>
              <div className="flex flex-wrap justify-end gap-2">
              {matchBadges.map((badge) => (
  <span
    key={badge}
    className="rounded-full border border-emerald-600 px-3 py-1 text-xs font-medium text-emerald-600"
    >
    {badge}
  </span>
))}
              </div>
            </div>

            {/* Stats bar */}
            <div className="flex divide-x divide-slate-100 border-b border-slate-100">
               {[
                {
                  label: "Total investment",
                  value: `${formatCurrency(brand.investment_min)}–${formatCurrency(brand.investment_max)}`,
                },
                { label: "Avg. unit volume (AUV)", value: formatCurrency(brand.auv) },
                { label: "Avg. payback period", value: brand.payback_period ?? "—" },
                { label: "Royalty on gross revenue", value: `${brand.royalty_pct}%` },
                { label: "Franchise fee", value: formatCurrency(brand.franchise_fee) },
              ].map((stat) => (
                <div key={stat.label} className="flex-1 px-6 py-4">
                  <p className="text-lg font-semibold">{stat.value}</p>
                  <p className="text-xs text-slate-500">{stat.label}</p>
                </div>
              ))}
            </div>

            <div className="flex flex-1">
              {/* Content */}
              <div className="flex-1 overflow-y-auto px-8 py-6">
                {/* Tabs */}
                <div className="mb-6 flex gap-6 border-b border-slate-100">
                  {TABS.map((tab) => (
                    <button
                      key={tab}
                      onClick={() => setActiveTab(tab)}
                      className={`pb-3 text-sm transition ${
                        activeTab === tab
                          ? "border-b-2 border-slate-900 font-medium text-slate-900"
                          : "text-slate-400 hover:text-slate-700"
                      }`}
                    >
                      {tab}
                    </button>
                  ))}
                </div>

                {activeTab === "Overview" && (
                  <div>
                    <p className="mb-8 text-sm leading-relaxed text-slate-700">
                      {brand.overview ?? brand.description}
                    </p>
                    <div className="grid gap-6 sm:grid-cols-2">
                      {[
                        { label: "Ownership model", value: brand.ownership_model_detail },
                        { label: "Artist structure", value: brand.artist_structure },
                        { label: "Location type", value: brand.location_type },
                        { label: "Operating hours", value: brand.operating_hours },
                        { label: "Staff at open", value: brand.staff_at_open },
                        { label: "Revenue mix", value: brand.revenue_mix },
                        { label: "Franchise system size", value: `${brand.unit_count}+ open` },
                        { label: "Years franchising", value: brand.years_franchising },
                      ].map((item) => (
                        <div key={item.label}>
                          <p className="text-xs text-slate-400">{item.label}</p>
                          <p className="mt-0.5 text-sm font-medium">{item.value ?? "—"}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
{activeTab === "Item 19 — earnings" && (
  <div>
    <p className="mb-8 text-sm text-slate-600">
      {brand.item19_summary}
    </p>

    {/* Three stats */}
    <div className="mb-8 grid grid-cols-3 gap-6">
      <div>
        <p className="text-xs text-slate-400">Median AUV</p>
        <p className="mt-1 text-2xl font-semibold">
          ${(brand.item19_median_gross / 1000).toFixed(0)}K
        </p>
        <p className="text-xs text-slate-400">Locations open 12+ mo</p>
      </div>
      <div>
        <p className="text-xs text-slate-400">Top quartile AUV</p>
        <p className="mt-1 text-2xl font-semibold">
          ${(brand.item19_top_quartile_gross / 1000).toFixed(0)}K
        </p>
        <p className="text-xs text-slate-400">Top 25% of open units</p>
      </div>
      <div>
        <p className="text-xs text-slate-400">Bottom quartile AUV</p>
        <p className="mt-1 text-2xl font-semibold">
          ${(brand.item19_bottom_quartile_gross / 1000).toFixed(0)}K
        </p>
        <p className="text-xs text-slate-400">Bottom 25% of open units</p>
      </div>
    </div>

    {/* P&L bars */}
<div className="space-y-4">
  {[
    {
      label: "Gross revenue (median)",
      amount: brand.item19_median_gross,
      pct: 100,
      color: "#3b82f6",
    },
    {
      label: "Cost of goods (supplies)",
      amount: brand.item19_cogs_amount,
      pct: brand.item19_cogs_pct,
      color: "#f87171",
    },
    {
      label: "Artist commissions (1099)",
      amount: brand.item19_artist_commissions_amount,
      pct: brand.item19_artist_commissions_pct,
      color: "#f87171",
    },
    {
      label: "Rent + occupancy",
      amount: brand.item19_rent_amount,
      pct: brand.item19_rent_pct,
      color: "#f87171",
    },
    {
      label: "Royalty + marketing",
      amount: brand.item19_royalty_amount,
      pct: brand.item19_royalty_pct,
      color: "#f87171",
    },
    {
      label: "Front desk + other labor",
      amount: brand.item19_labor_amount,
      pct: brand.item19_labor_pct,
      color: "#f87171",
    },
    {
      label: "Other operating expenses",
      amount: brand.item19_other_expenses_amount,
      pct: brand.item19_other_expenses_pct,
      color: "#f87171",
    },
    {
      label: "Owner earnings (EBITDA)",
      amount: brand.item19_owner_earnings_amount,
      pct: brand.item19_owner_earnings_pct,
      color: "#10b981",
    },
  ].map((row) => (
    <div key={row.label}>
      <div className="mb-1 flex items-center justify-between">
        <p className="text-sm text-slate-700">{row.label}</p>
        <p className="text-sm text-slate-600">
          ${row.amount?.toLocaleString()} ({row.pct}%)
        </p>
      </div>
      <div className="h-2 w-full rounded-full bg-slate-100">
        <div
          className="h-2 rounded-full"
          style={{
            width: `${row.pct}%`,
            backgroundColor: row.color,
          }}
        />
      </div>
    </div>
  ))}
</div>

    {/* Footnote */}
    {brand.item19_notes && (
      <p className="mt-8 text-xs text-slate-400">
        * {brand.item19_notes}
      </p>
    )}
  </div>
)}

{activeTab === "Franchisee validation" && (
  <div>
    <p className="mb-8 text-sm text-slate-600">
      {brand.validation_intro}
    </p>
    <div className="space-y-8">
    {brand.franchisee_validations?.map((f) => (
        <div key={f.name}>
          <p className="mb-4 text-sm italic leading-relaxed text-slate-700">
            "{f.quote}"
          </p>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-full bg-slate-700 text-xs font-bold text-white">
                {f.initials}
              </div>
              <div>
                <p className="text-sm font-medium">{f.name}</p>
                <p className="text-xs text-slate-500">
                  {f.location} · open {f.months_open} months
                </p>
              </div>
            </div>
            <div className="flex gap-0.5">
              {[1, 2, 3, 4, 5].map((star) => (
                <span
                  key={star}
                  className={
                    star <= f.rating
                      ? "text-amber-400"
                      : "text-slate-200"
                  }
                >
                  ★
                </span>
              ))}
            </div>
          </div>
        </div>
      ))}
    </div>
  </div>
)}

{activeTab === "Territory" && (
  <div>
    <p className="mb-8 text-sm text-slate-600">
      {brand.territory_description}
    </p>
    <div className="divide-y divide-slate-100">
      {brand.territories?.map((t) => (
        <div
          key={t.id}
          className="flex items-center justify-between py-3"
        >
          <p className="text-sm text-slate-700">{t.territory_name}</p>
          <span
            className={`text-sm font-medium ${
              t.status === "Open"
                ? "text-emerald-600"
                : t.status === "Limited"
                ? "text-amber-500"
                : "text-slate-400"
            }`}
          >
            {t.status}
          </span>
        </div>
      ))}
    </div>
  </div>
)}

{activeTab === "Support model" && (
  <div className="divide-y divide-slate-100">
    <div className="flex gap-8 py-5">
      <div className="w-48 shrink-0">
        <p className="text-sm text-slate-500">On-The-Job Training</p>
      </div>
      <p className="text-sm font-medium">
        {brand.support_onthejob_hours} hours
      </p>
    </div>
    <div className="flex gap-8 py-5">
      <div className="w-48 shrink-0">
        <p className="text-sm text-slate-500">Classroom Training</p>
      </div>
      <p className="text-sm font-medium">
        {brand.support_classroom_hours} hours
      </p>
    </div>
    <div className="flex gap-8 py-5">
      <div className="w-48 shrink-0">
        <p className="text-sm text-slate-500">Ongoing Support</p>
      </div>
      <div className="grid grid-cols-2 gap-x-8 gap-y-2">
        {brand.support_values
          ?.filter((s) => s.support_items.support_type === "ongoing")
          .map((s) => (
            <div key={s.support_items.id} className="flex items-center gap-2">
              <span className={s.provided ? "text-emerald-500" : "text-slate-300"}>
                {s.provided ? "✓" : "✗"}
              </span>
              <p className={`text-sm ${s.provided ? "" : "text-slate-400"}`}>
                {s.support_items.item_name}
              </p>
            </div>
          ))}
      </div>
    </div>
    <div className="flex gap-8 py-5">
      <div className="w-48 shrink-0">
        <p className="text-sm text-slate-500">Marketing Support</p>
      </div>
      <div className="grid grid-cols-2 gap-x-8 gap-y-2">
        {brand.support_values
          ?.filter((s) => s.support_items.support_type === "marketing")
          .map((s) => (
            <div key={s.support_items.id} className="flex items-center gap-2">
              <span className={s.provided ? "text-emerald-500" : "text-slate-300"}>
                {s.provided ? "✓" : "✗"}
              </span>
              <p className={`text-sm ${s.provided ? "" : "text-slate-400"}`}>
                {s.support_items.item_name}
              </p>
            </div>
          ))}
      </div>
    </div>
    <div className="flex gap-8 py-5">
      <div className="w-48 shrink-0">
        <p className="text-sm text-slate-500">Marketing Support</p>
      </div>
      <div className="grid grid-cols-2 gap-x-8 gap-y-2">
        {brand.support_items
          ?.filter((s) => s.support_type === "marketing")
          .map((s) => (
            <div key={s.id} className="flex items-center gap-2">
              <span className="text-emerald-500">✓</span>
              <p className="text-sm">{s.item_name}</p>
            </div>
          ))}
      </div>
    </div>
  </div>
)}

{activeTab === "Documents" && (
  <div className="divide-y divide-slate-100">
    {brand.documents?.map((doc) => (
      <div key={doc.id} className="flex items-center justify-between py-4">
        <div>
          <p className="text-sm font-medium">{doc.title}</p>
          <p className="mt-0.5 text-xs text-slate-500">{doc.description}</p>
        </div>
        <button
          onClick={() => {
            if (doc.access_type === "Download" && doc.file_url) {
              window.open(doc.file_url, "_blank");
            }
          }}
          className={`shrink-0 text-sm ${
            doc.access_type === "Download"
              ? "text-slate-600 hover:text-slate-900"
              : "text-amber-600 hover:text-amber-800"
          }`}
        >
          {doc.access_type}
        </button>
      </div>
    ))}
  </div>
)}

{activeTab !== "Overview" &&
  activeTab !== "Item 19 — earnings" &&
  activeTab !== "Franchisee validation" &&
  activeTab !== "Territory" &&
  activeTab !== "Support model" &&
  activeTab !== "Documents" && (
  <div className="flex items-center justify-center py-20">
    <p className="text-sm text-slate-400">
      {activeTab} content coming soon.
    </p>
  </div>
)}
                
              </div>

              {/* Right panel */}
              <div className="w-64 shrink-0 border-l border-slate-100 px-6 py-6">
                <p className="mb-4 text-sm font-medium">Your next steps</p>

                <button className="mb-3 w-full rounded-lg bg-slate-900 px-4 py-3 text-sm font-medium text-white transition hover:bg-slate-800">
                  Book speed connect meeting
                </button>
                <button className="mb-3 w-full text-left text-sm text-slate-600 hover:text-slate-900">
                  Request FDD access
                </button>
                <button className="mb-6 w-full text-left text-sm text-slate-600 hover:text-slate-900">
                  Watch brand pitch stage →
                </button>

                {/* Contact */}
                <div className="mb-6 flex items-start gap-3">
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-slate-700 text-xs font-bold text-white">
                    {getInitials(brand.rep_name ?? "TF")}
                  </div>
                  <div>
                    <p className="text-sm font-medium">{brand.rep_name}</p>
                    <p className="text-xs text-slate-500">{brand.rep_title}</p>
                    <p className="text-xs text-emerald-600">{brand.rep_availability ?? "Available today"}</p>
                  </div>
                </div>

                {/* Pitch */}
                <div className="mb-6 border-t border-slate-100 pt-5">
                  <p className="mb-2 text-xs font-medium text-slate-500">
                    Pitch stage session
                  </p>
                  <p className="text-sm">{brand.pitch_time ?? "—"}</p>
                  <p className="text-xs text-slate-500">
                    {brand.pitch_stage} · {brand.pitch_duration}
                  </p>
                  <button className="mt-3 text-sm text-slate-600 hover:text-slate-900">
                    Add to my schedule
                  </button>
                </div>

                {/* Engagement score */}
                <div className="border-t border-slate-100 pt-5">
                  <div className="flex items-center justify-between">
                    <p className="text-xs text-slate-500">Your engagement score</p>
                    <p className="text-lg font-semibold">74</p>
                  </div>
                  <p className="mt-1 text-xs text-slate-400">
                    Based on your activity with this brand
                  </p>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

const NAV_SECTIONS = [
  {
    label: "EVENT",
    items: [
      { name: "Dashboard", badge: null, path: "/dashboard" },
      { name: "My matched brands", badge: 3, path: "/dashboard/matched-brands" },
      { name: "My schedule", badge: 4, path: "/dashboard/schedule" },
      { name: "Speed connect", badge: 2, path: "/dashboard/speed-connect" },
    ],
  },
  {
    label: "DISCOVER",
    items: [
      { name: "Education sessions", badge: null, path: "/dashboard/education" },
      { name: "All brands", badge: null, path: "/dashboard/all-brands" },
    ],
  },
  {
    label: "MY ACTIVITY",
    items: [
      { name: "Saved brands", badge: null, path: "/dashboard/saved-brands" },
      { name: "Notes & history", badge: null, path: "/dashboard/notes" },
    ],
  },
];

const NOTES = [
  {
    initials: "FI",
    color: "bg-slate-900",
    title: "Fine Ink Studios — Speed connect notes (shared)",
    timestamp: "Today · 3:30pm",
    shared: true,
    body: "Interested in Tampa Bay territory — Westchase or South Tampa zone preferred. Asked about Item 19 breakdown by market type — rep will follow up with market-level data. Semi-absentee model confirmed: 10–15 hrs/week after ramp. Want to speak with 2 existing franchisees before Discovery Day decision.",
    tags: [
      "Tampa territory",
      "Item 19 follow-up pending",
      "Validation calls requested",
      "Discovery Day interest",
    ],
  },
  {
    initials: "CO",
    color: "bg-emerald-800",
    title: "Complete Outdoor Living — My notes (private)",
    timestamp: "Today · 11:20am",
    shared: false,
    body: "Good pitch from Paul. $145K entry point works. No Item 19 yet — launching 2026 so it's a pro forma. Revenue model is project-based which I like — no inventory risk. Territory availability in Tampa and Sarasota looks strong. Main question: how is the contractor network managed and what happens if a contractor relationship breaks down mid-project?",
    tags: [
      "Pro forma only — no Item 19",
      "Contractor model question",
      "Tampa territory open",
    ],
  },
  {
    initials: "ED",
    color: "bg-slate-300",
    textColor: "text-slate-700",
    title: "Education session — How to read a franchise FDD",
    timestamp: "Today · 9:00am",
    shared: false,
    body: "Key takeaways: Item 19 is voluntary but its absence is a red flag. Item 21 (financial statements) matters — look for 3 years of audited statements. Item 20 shows unit count changes — watch for closures. Always ask for a list of former franchisees and call at least 3. FDD must be delivered 14 days before signing.",
    tags: [
      "Item 19 — voluntary but critical",
      "Call former franchisees",
      "14-day rule",
    ],
  },
];

export default function NotesPage() {
  const router = useRouter();
  const [activeNav, setActiveNav] = useState("Notes & history");

  return (
    <div className="flex min-h-screen bg-white text-slate-900">
      {/* Sidebar */}
      <aside className="flex w-56 shrink-0 flex-col bg-slate-900 text-white">
        <div className="px-5 pt-6 pb-4">
          <p className="text-sm font-semibold">
            <span className="text-amber-400">The Franchise Edge</span>
          </p>
          <p className="text-xs text-slate-400">
            Virtual Expo · Spring 2026 · Live now
          </p>
        </div>

        <div className="mx-4 mb-6 flex items-center gap-3 rounded-lg bg-slate-800 px-3 py-3">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-amber-500 text-xs font-bold text-white">
            SC
          </div>
          <div>
            <p className="text-sm font-medium">Scott C.</p>
            <p className="text-xs text-slate-400">
              Readiness score: 82 · 3 matches
            </p>
          </div>
        </div>

        <nav className="flex-1 space-y-5 px-4">
          {NAV_SECTIONS.map((section) => (
            <div key={section.label}>
              <p className="mb-2 text-xs font-semibold tracking-widest text-slate-500">
                {section.label}
              </p>
              <ul className="space-y-1">
                {section.items.map((item) => (
                  <li key={item.name}>
                    <button
                      onClick={() => {
                        setActiveNav(item.name);
                        router.push(item.path);
                      }}
                      className={`flex w-full items-center justify-between rounded-lg px-3 py-2 text-sm transition ${
                        activeNav === item.name
                          ? "bg-slate-700 text-white"
                          : "text-slate-400 hover:bg-slate-800 hover:text-white"
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        <span className="h-1.5 w-1.5 rounded-full bg-slate-500" />
                        {item.name}
                      </span>
                      {item.badge && (
                        <span className="rounded-full bg-amber-500 px-1.5 py-0.5 text-xs font-semibold text-white">
                          {item.badge}
                        </span>
                      )}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </nav>

        <div className="px-5 py-5">
          <p className="text-xs text-slate-500">Pressure guarantee:</p>
          <p className="text-xs text-amber-400">promise@thefranchiseedge.com</p>
        </div>
      </aside>

      {/* Main */}
      <div className="flex flex-1 flex-col">
        <div className="flex items-center justify-between border-b border-slate-100 px-8 py-4">
          <h1 className="text-lg font-semibold">Notes & history</h1>
          <div className="flex items-center gap-6 text-sm text-slate-500">
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-emerald-500" />
              Event is live
            </span>
            <span>Day 1 · 1:42 PM ET</span>
          </div>
        </div>

        <main className="flex-1 px-8 py-8">
          <p className="mb-8 text-sm text-slate-500">
            Auto-saved notes from your sessions and speed connect meetings.
            Shared notes are visible to both you and the brand rep.
          </p>

          <div className="space-y-8">
            {NOTES.map((note, i) => (
              <div key={i} className="rounded-xl border border-slate-100 bg-white p-6 shadow-sm">
                {/* Header */}
                <div className="mb-4 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div
                      className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${note.color} text-xs font-bold ${note.textColor ?? "text-white"}`}
                    >
                      {note.initials}
                    </div>
                    <div>
                      <p className="text-sm font-medium">{note.title}</p>
                    </div>
                  </div>
                  <p className="shrink-0 text-xs text-slate-400">
                    {note.timestamp}
                  </p>
                </div>

                {/* Body */}
                <p className="text-sm leading-relaxed text-slate-700">
                  {note.body}
                </p>

                {/* Tags */}
                <div className="mt-4 flex flex-wrap gap-2">
                  {note.tags.map((tag) => (
                    <span
                      key={tag}
                      className="rounded-full border border-slate-200 px-3 py-0.5 text-xs text-slate-500"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </main>
      </div>
    </div>
  );
}
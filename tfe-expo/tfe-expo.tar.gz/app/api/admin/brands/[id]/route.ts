import { NextResponse } from "next/server";
import { createAdminClient } from "@/utils/supabase/admin";

export async function GET(
  request: Request,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await context.params;
    const supabase = createAdminClient();

    const { data: brand, error } = await supabase
      .from("brands")
      .select("*")
      .eq("id", id)
      .single();

    if (error) throw error;

    const { data: territories } = await supabase
      .from("brand_territories")
      .select("*")
      .eq("brand_id", id)
      .order("display_order", { ascending: true });

    const { data: supportValues } = await supabase
      .from("brand_support_values")
      .select("provided, support_items(id, item_name, support_type)")
      .eq("brand_id", id);

    const { data: documents } = await supabase
      .from("brand_documents")
      .select("*")
      .eq("brand_id", id)
      .order("display_order", { ascending: true });

    const { data: validations } = await supabase
      .from("franchisee_validations")
      .select("*")
      .eq("brand_id", id)
      .order("display_order", { ascending: true });

    return NextResponse.json({
      brand: {
        ...brand,
        territories: territories ?? [],
        support_values: supportValues ?? [],
        documents: documents ?? [],
        franchisee_validations: validations ?? [],
      },
    }, { status: 200 });
  } catch (error) {
    console.error("ADMIN BRAND FETCH ERROR:", error);
    return NextResponse.json(
      { error: "Unable to fetch brand." },
      { status: 500 }
    );
  }
}
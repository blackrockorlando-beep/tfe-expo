"use client";

import { useRouter } from "next/navigation";

const BUYER_LINKS = [
  { label: "Buyer Registration", description: "5-step onboarding flow", path: "/register" },
  { label: "Buyer Dashboard", description: "Full expo experience", path: "/dashboard" },
  { label: "Fine Ink Studios Pavilion", description: "Brand pavilion demo", path: "/dashboard/pavilion/fine-ink-studios" },
  { label: "Jag Cantina Pavilion", description: "Brand pavilion demo", path: "/dashboard/pavilion/jag-cantina" },
  { label: "Complete Outdoor Living Pavilion", description: "Brand pavilion demo", path: "/dashboard/pavilion/complete-outdoor-living" },
];

const ADMIN_LINKS = [
  { label: "Admin Dashboard", description: "Overview and stats", path: "/admin" },
  { label: "Manage Franchisors", description: "View and edit brands", path: "/admin/franchisors" },
  { label: "Add New Franchisor", description: "8-step onboarding wizard", path: "/admin/franchisors/new" },
  { label: "Manage Buyers", description: "View registered buyers", path: "/admin/buyers" },
];

export default function HomePage() {
  const router = useRouter();

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <header className="bg-slate-900 text-white px-8 py-6">
        <div className="mx-auto max-w-5xl flex items-center justify-between">
          <div>
            <p className="text-sm font-semibold">
              <span className="text-amber-400">The Franchise Edge</span>
            </p>
            <p className="text-xs text-slate-400 mt-0.5">
              Virtual Expo Platform · Internal Navigation
            </p>
          </div>
          <span className="rounded-full bg-emerald-600 px-3 py-1 text-xs font-medium text-white">
            Dev Build
          </span>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-8 py-10">
        <div className="mb-8 rounded-xl border border-amber-200 bg-amber-50 px-5 py-4">
          <p className="text-sm text-amber-800">
            This is the internal development navigation hub. Use the links below to access all platform sections. A public-facing landing page will replace this before launch.
          </p>
        </div>

        <div className="grid gap-8 sm:grid-cols-2">
          {/* Buyer section */}
          <div>
            <div className="mb-4 flex items-center gap-2">
              <div className="h-2 w-2 rounded-full bg-emerald-500" />
              <h2 className="text-sm font-semibold uppercase tracking-widest text-slate-500">
                Buyer Experience
              </h2>
            </div>
            <div className="space-y-2">
              {BUYER_LINKS.map((link) => (
                <button
                  key={link.path}
                  onClick={() => router.push(link.path)}
                  className="flex w-full items-center justify-between rounded-xl border border-slate-200 bg-white px-5 py-4 text-left shadow-sm transition hover:border-slate-400 hover:shadow-md"
                >
                  <div>
                    <p className="text-sm font-medium">{link.label}</p>
                    <p className="text-xs text-slate-500">{link.description}</p>
                  </div>
                  <span className="text-slate-400">→</span>
                </button>
              ))}
            </div>
          </div>

          {/* Admin section */}
          <div>
            <div className="mb-4 flex items-center gap-2">
              <div className="h-2 w-2 rounded-full bg-amber-500" />
              <h2 className="text-sm font-semibold uppercase tracking-widest text-slate-500">
                Admin Portal
              </h2>
            </div>
            <div className="space-y-2">
              {ADMIN_LINKS.map((link) => (
                <button
                  key={link.path}
                  onClick={() => router.push(link.path)}
                  className="flex w-full items-center justify-between rounded-xl border border-slate-200 bg-white px-5 py-4 text-left shadow-sm transition hover:border-slate-400 hover:shadow-md"
                >
                  <div>
                    <p className="text-sm font-medium">{link.label}</p>
                    <p className="text-xs text-slate-500">{link.description}</p>
                  </div>
                  <span className="text-slate-400">→</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Platform status */}
        <div className="mt-10 rounded-xl border border-slate-200 bg-white px-6 py-5 shadow-sm">
          <h2 className="mb-4 text-sm font-semibold">Platform status</h2>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {[
              { label: "Registration flow", status: "Live" },
              { label: "Buyer dashboard", status: "Live" },
              { label: "Brand pavilions", status: "Live" },
              { label: "Admin portal", status: "Live" },
              { label: "Franchisor onboarding", status: "Live" },
              { label: "Email confirmation", status: "Pending" },
              { label: "Buyer login", status: "Pending" },
              { label: "Admin auth", status: "Pending" },
            ].map((item) => (
              <div key={item.label} className="flex items-center gap-2">
                <span className={`h-1.5 w-1.5 rounded-full ${item.status === "Live" ? "bg-emerald-500" : "bg-slate-300"}`} />
                <div>
                  <p className="text-xs font-medium">{item.label}</p>
                  <p className={`text-xs ${item.status === "Live" ? "text-emerald-600" : "text-slate-400"}`}>
                    {item.status}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
"use client";

import { useRouter } from "next/navigation";

export default function AdminDashboard() {
  const router = useRouter();

  return (
    <div className="px-8 py-8">
      <h1 className="text-xl font-semibold">Admin Dashboard</h1>
      <p className="mt-1 text-sm text-slate-500">
        TFE Virtual Expo management portal
      </p>

      <div className="mt-8 grid grid-cols-3 gap-6">
        <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
          <p className="text-2xl font-semibold">3</p>
          <p className="mt-1 text-sm text-slate-600">Active brands</p>
          <button
            onClick={() => router.push("/admin/franchisors")}
            className="mt-4 text-sm text-amber-600 hover:underline"
          >
            Manage franchisors →
          </button>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
          <p className="text-2xl font-semibold">0</p>
          <p className="mt-1 text-sm text-slate-600">Registered buyers</p>
          <button
            onClick={() => router.push("/admin/buyers")}
            className="mt-4 text-sm text-amber-600 hover:underline"
          >
            View buyers →
          </button>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
          <p className="text-2xl font-semibold">0</p>
          <p className="mt-1 text-sm text-slate-600">Speed connects booked</p>
        </div>
      </div>

      <div className="mt-8">
        <button
          onClick={() => router.push("/admin/franchisors/new")}
          className="rounded-lg bg-slate-900 px-5 py-2.5 text-sm font-medium text-white hover:bg-slate-800"
        >
          + Add new franchisor
        </button>
      </div>
    </div>
  );
}